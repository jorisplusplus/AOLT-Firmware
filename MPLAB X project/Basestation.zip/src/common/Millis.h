#ifndef MILLIS_H
/** DEFINES ********************************************************/
#define	MILLIS_H

/** VARIABLES ******************************************************/
unsigned long Millis;

/** PROTOTYPES *****************************************************/
void initMillis(void);
void handleMillis(void);

#endif	/* MILLIS_H */

