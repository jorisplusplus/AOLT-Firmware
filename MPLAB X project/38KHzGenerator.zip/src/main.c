/* 
 * File:   main.c
 * Author: Joris
 *
 * Created on July 15, 2014, 6:28 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <xc.h>
#include <pic12f629.h>

#define _XTAL_FREQ 4000000
/*
 * 
 */


void main(void) {
    TRISIO = 0b00111000;

    while(1) {
        if(GPIObits.GP5 == 1) {
            GPIObits.GP1 = 1;
            GPIObits.GP0 = 1;
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            GPIObits.GP0 = 0;
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
            NOP();
        } else {
            GPIObits.GP0 = 0;
            GPIObits.GP1 = 0;
        }
    }
}

